<html>
<head><title>php info</title></head>
<body>

<?php phpinfo() ?>

</body>
</html>
